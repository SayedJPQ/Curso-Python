#Creacion de setup
from setuptools import setup
setup(name="paquete redondear",
	version="1.0",
	description="Sirve para redonderar decimales",
	author="Sayed",
	author_email="sayedjquiros@gmail.com",
	packages=["Prueba"]
)