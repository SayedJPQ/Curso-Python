def redondear(numero):
	print("El numero redondeado es:", round(numero))